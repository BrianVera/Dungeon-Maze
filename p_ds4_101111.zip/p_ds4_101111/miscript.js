
	$(document).ready(function(){
		$('#formulario').corner();  // corner: redondeo 
		$('#zerg').corner();
		$('#protoss').corner();
		$('#terran').corner();
		var seleccionado="";
		var rutasfondo=['zerg','terran','protoss'];
		$('#formulario').hide();
		
		$('#razas li img').click(function(){
			if(seleccionado==this.id){		// si no hay nada seleccionado
				$('body').css('background-image','none');  // pone el fondo blanco
				seleccionado="";
				$('#formulario').hide();  // esconde el formulario
				$('#'+this.id).css('border','none');  // le quita el borde
			}else{		// le asigna un index dependiendo la imagen seleccionada
				var index=0;	
				switch(this.id){
				case 'terran':index=1;
				break;
				case 'protoss': index=2; 		
				break;
				default:index=0;
				}
			
			seleccionado=this.id;
		
			$('#zerg').css('border','none');
			$('#protoss').css('border','none');
			$('#terran').css('border','none');
		
			$('#formulario').show();
			$('body').css('background-image','url("img/'+rutasfondo[index]+'-fondo.jpg")');
			$('#'+rutasfondo[index]).css('border','3px solid red');
		 }
    });
	});
	
	
	
	